import "./style.css"

/* =========================
   CHIAVI LOCAL STORAGE
========================= */

// Chiave usata per salvare i task
const CHIAVE = "todo-tasks"

// Chiave usata per salvare il nome dell'utente
const CHIAVE_NOME = "todo-nome"

/* =========================
   STATO
========================= */

// Funzione che recupera i task salvati
// nel localStorage del browser
function caricaStato() {

  const testo =
    localStorage.getItem(CHIAVE)

  // Se non esiste nulla salvato
  // restituisce un array vuoto
  if (testo === null) {
    return []
  }

  // Trasforma il testo JSON
  // in un vero array JavaScript
  return JSON.parse(testo)
}

// Variabile principale dell'app.
// Contiene tutti i task.
let tasks = caricaStato()

/* =========================
   ELEMENTI PAGINA
========================= */

// Recupero degli elementi HTML
// che serviranno nel programma

const lista =
  document.querySelector("#lista")

const info =
  document.querySelector("#info")

const form =
  document.querySelector("#form-task")

const campo =
  document.querySelector("#campo-task")

const areaNome =
  document.querySelector("#area-nome")

const campoNome =
  document.querySelector("#campo-nome")

const salvaNomeBtn =
  document.querySelector("#salva-nome")

const benvenuto =
  document.querySelector("#benvenuto")

const bottoneElimina =
  document.querySelector(
    "#elimina-completati"
  )

/* =========================
   SALVATAGGIO
========================= */

// Salva lo stato attuale dei task
// nel localStorage
function salvaStato() {

  localStorage.setItem(
    CHIAVE,
    JSON.stringify(tasks)
  )
}

/* =========================
   NOME UTENTE
========================= */

// Mostra il messaggio di bentornato
// se il nome è già stato salvato
function mostraNome() {

  const nome =
    localStorage.getItem(
      CHIAVE_NOME
    )

  if (nome) {

    // Scrive il messaggio
    benvenuto.textContent =
      `Bentornato, ${nome}`

    // Nasconde input e pulsante
    areaNome.style.display =
      "none"
  }
}

// Evento sul pulsante salva nome
salvaNomeBtn.addEventListener(
  "click",
  () => {

    const nome =
      campoNome.value.trim()

    // Non salva nomi vuoti
    if (nome === "") return

    // Salva il nome
    localStorage.setItem(
      CHIAVE_NOME,
      nome
    )

    mostraNome()
  }
)

/* =========================
   RENDER
========================= */

// Render significa "ridisegnare"
// l'interfaccia in base allo stato
function render() {

  // Copia dell'array ordinata
  // con i completati in fondo
  const ordinati =
    [...tasks].sort(
      (a, b) =>
        a.completed - b.completed
    )

  // Genera tutto l'HTML della lista
  lista.innerHTML =
    ordinati
      .map(task => `
        <li
          class="${task.completed
            ? "fatto"
            : ""}"
          data-id="${task.id}">

          <span class="titolo">
            ${task.title}
          </span>

          <button
            class="elimina"
            data-id="${task.id}">
            ×
          </button>

        </li>
      `)
      .join("")

  // Conta quanti task sono completati
  const completati =
    tasks.filter(
      t => t.completed
    ).length

  // Conta quanti task restano da fare
  const daFare =
    tasks.filter(
      t => !t.completed
    ).length

  let messaggio = ""

  // Nessun task presente
  if (tasks.length === 0) {

    messaggio =
      "Non hai task. Buona giornata."
  }

  // Tutti completati
  else if (
    completati === tasks.length
  ) {

    messaggio =
      "Fatto tutto. Complimenti."
  }

  // Alcuni completati
  else {

    messaggio =
      `Ti restano ${daFare} task su ${tasks.length}.`
  }

  // Aggiorna le statistiche
  info.textContent =
    `Totali: ${tasks.length}
     · Completati: ${completati}
     · Da fare: ${daFare}
     | ${messaggio}`

  // Mostra il pulsante elimina completati
  // solo se esiste almeno un task completato
  bottoneElimina.style.display =
    completati > 0
      ? "block"
      : "none"
}

/* =========================
   AZIONI
========================= */

// Aggiunge un nuovo task
function addTask(title) {

  const pulito =
    title.trim()

  // Impedisce task vuoti
  if (pulito === "") return

  const nuovoTask = {

    // ID univoco basato sull'ora
    id: Date.now(),

    title: pulito,

    // All'inizio non è completato
    completed: false
  }

  // Crea un nuovo array
  tasks = [
    ...tasks,
    nuovoTask
  ]

  salvaStato()
  render()
}

// Cambia lo stato completato/non completato
function toggleTask(id) {

  tasks = tasks.map(
    task =>
      task.id === id
        ? {
            ...task,
            completed:
              !task.completed
          }
        : task
  )

  salvaStato()
  render()
}

// Elimina un singolo task
function deleteTask(id) {

  tasks = tasks.filter(
    task => task.id !== id
  )

  salvaStato()
  render()
}

// Elimina tutti i task completati
function deleteCompleted() {

  // Chiede conferma
  const conferma =
    confirm(
      "Vuoi eliminare tutti i task completati?"
    )

  if (!conferma) return

  // Mantiene solo quelli NON completati
  tasks =
    tasks.filter(
      task => !task.completed
    )

  salvaStato()
  render()
}

/* =========================
   EVENTI
========================= */

// Evento invio form
form.addEventListener(
  "submit",
  evento => {

    // Evita il refresh della pagina
    evento.preventDefault()

    addTask(
      campo.value
    )

    // Svuota l'input
    campo.value = ""

    // Rimette il cursore nell'input
    campo.focus()
  }
)

// Gestisce i click sulla lista
lista.addEventListener(
  "click",
  evento => {

    const elemento =
      evento.target

    // Click sul pulsante elimina
    if (
      elemento.classList.contains(
        "elimina"
      )
    ) {

      deleteTask(
        Number(
          elemento.dataset.id
        )
      )

      return
    }

    // Click sul task
    const riga =
      elemento.closest("li")

    if (riga) {

      toggleTask(
        Number(
          riga.dataset.id
        )
      )
    }
  }
)

// Click sul pulsante elimina completati
bottoneElimina.addEventListener(
  "click",
  deleteCompleted
)

/* =========================
   AVVIO
========================= */

// Mostra il nome salvato
mostraNome()

// Disegna la pagina
render()